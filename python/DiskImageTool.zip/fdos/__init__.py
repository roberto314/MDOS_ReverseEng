# Ths file is part of: ditool.py - The Disk Image Tool
# 2026, R. Offner
# Version: 2.0
#
# Version History:
# 2.0: rewrite with dictionaries
# 1: first Version with Lists

import os

class class_FDOS(object):

    def __init__(self, parent, fspec, verbose):
        #self.parent = parent
        self.fspec = fspec
        self.verbose = verbose
        self.parent = parent
        if self.verbose != 0:
            print(f'Imageformat:')
            print(f'Tracks: {fspec["Tracks"]}')
            print(f'Sides: {fspec["Sides"]}')
            print(f'Sectors: {fspec["Sectors"]}')
            print(f'Bytes / Sector: {fspec["bps"]}')
            print(f'Directory starts at: 0x{fspec["Dirstart"]:04X}')
            print(f'Files starts at: 0x{fspec["Filestart"]:04X}')
            print(f'File Entry size: {fspec["Direntrysize"]}')
            print(f'Emptyvalue: {fspec["Emptyval"]:02X}')
    #----------------------------------
    def print_examples(self):
        print(f'')
        for k, v in self.fspec.items():
            print(f'{k}: 0x{v:04X}/{v}')
        print(f'')
    #----------------------------------
    def isascii(self,b):
        try:
            s = b.decode("ascii")
        except UnicodeDecodeError:
            #print(f'Deleted File: xx{(b[2:8]).decode("ascii")}')
            return False
        else:
            # Check only first Character. If Space or NON-Ascii return false
            if ord(s[0]) > 0x20 and ord(s[0]) < 0x80:
                #print(f'Str.: {s} with char: {ord(s[0])} is ACII')
                return True
            else:
                #print(f'Str.: {s} with char: {ord(s[0])} is not ACII')
                return False
            #print(f'Str.: {s} is ACII')
            #return len(s) == len(s.encode("ascii"))
    #----------------------------------
    def conv16 (self, data, startoff):
        number = data[startoff]*256
        number += data[startoff+1]
        return number    
    #----------------------------------
    def chs_to_offset(self, c, h, s):
        offset = (self.fspec["Sectors"] * self.fspec["bps"] * c) + self.fspec["bps"] * s
        return offset
    #----------------------------------
    def offset_to_chs(self, off):
        totalsec = int(off / self.fspec["bps"])
        track = (totalsec / self.fspec["Sectors"]) # How many Tracks are these
        s = (totalsec % self.fspec["Sectors"])  # How many Sectors are rest
        c = int(track)
        h = 0
        if self.verbose > 0:
            print(f'off: {off:04X} c: {c} s: {s} totalsec: {totalsec} Track: {track}')
        return c, h, s
    #----------------------------------
    def create_image(self):
        img = bytearray(self.fspec["Emptyval"] for _ in range(self.fspec["Imagesize"])) # make empty imagefile with correct size
        return img
    #----------------------------------
    # parses the directory block
    def get_dir(self, imgfile):
        entries = [] # List of all Entries (plus header)
        offset = self.fspec["Dirstart"]
        header = []                   # Build the Header
        header.append("Name        ")
        header.append("Password")
        header.append("STrk")
        header.append("SSec")
        header.append("SSiz")
        header.append("Type")
        header.append("SAddr")
        header.append("EAddr")
        header.append("Exec")
        header.append("Hi")
        header.append("Sp0")
        header.append("Sp1")
        header.append("Sp2")
        entries.append(header)
        while (offset < self.fspec["Filestart"]):
            entry = {}   # Dictionary of one Directory Entry
            if self.isascii(imgfile[offset:(offset+8)]): # We have a "real" directory entry
                name = (imgfile[offset:(offset+8)]).decode("ascii")
                if "DOS" in name: # Print System files in Green
                    entry["Name"]        = ["strg", name]
                else:
                    entry["Name"]        = ["strw", name]
                entry["Password"]    = ["strw", '\''+(imgfile[(offset+8):(offset+16)]).decode("ascii")+'\'']
                entry["StartTrack"]  = ["hx8", imgfile[(offset+16)]]
                entry["StartSector"] = ["hx8", imgfile[(offset+17)]]
                entry["SizeinSecs"]  = ["hx8", self.conv16(imgfile, (offset+18))]
                FTYPE = int((imgfile[(offset+20)])) # What is the Filetype
                FTYPETXT = ''
                if (FTYPE == 0x00):
                    FTYPETXT = 'Blank'
                elif(FTYPE == 0x11):
                    FTYPETXT = 'System'
                elif(FTYPE == 0x22):
                    FTYPETXT = 'Object'
                elif(FTYPE == 0x55):
                    FTYPETXT = 'Basic'
                elif(FTYPE == 0x77):
                    FTYPETXT = 'Cores'
                elif(FTYPE == 0x99):
                    FTYPETXT = 'B.Data'
                entry["Filetype"]    = ["strw",  FTYPETXT]
                entry["SAddr"]       = ["hx16", self.conv16(imgfile, (offset+21))]
                entry["EAddr"]       = ["hx16", self.conv16(imgfile, (offset+23))]
                entry["Exec"]        = ["hx16", self.conv16(imgfile, (offset+25))]
                entry["Hi"]          = ["hx16", self.conv16(imgfile, (offset+27))]
                entry["Sp0"]         = ["hx8",  (imgfile[(offset+29)])]
                entry["Sp1"]         = ["hx8",  (imgfile[(offset+30)])]
                entry["Sp2"]         = ["hx8",  (imgfile[(offset+31)])]
                entries.append(entry)                 # append to list of entries
            else:
                break
            offset += self.fspec["Direntrysize"]  # cue to next entry
        
        # Print statistics at the end of listing
        stats = {}
        stats["Next free Track: "]    = ["hx8", imgfile[(offset+16)]]
        stats["Next free Sector: "]   = ["hx8", imgfile[(offset+17)]]
        stats["Total free sectors: "] = ["hx8", (self.conv16(imgfile, (offset+18)))]

        return entries, stats
    #----------------------------------
    # Prints out Directory
    def print_dir(self, img):
        print(f'Showing Directory. (all values in hex!)') # Directory is easy, it starts @ 0x1400 until a 0xFF is found @ first position
        entries, stats = self.get_dir(img)

        for idx,e in enumerate(entries): # cycle through entries
            if idx == 0:                 # first entry is the header
                for h in e:
                   print(f'{h}', end="\t") # Print keys and TAB
                print(f'')
            else:
                for k, v in e.items():
                    if 'hx8' == v[0]:                   # Print 8-Bit HEX
                        print(f'{v[1]:02X}', end="\t")
                    elif 'arr8x' == v[0]:
                        self.parent.dump_data(v[1],16)
                    elif 'hx16' == v[0]:                  # Print 16-Bit HEX
                        print(f'{v[1]:04X}', end="\t")
                    elif 'strw' == v[0]:                  # Print String in White
                        print(f'{v[1]}', end="\t")
                    elif 'strg' == v[0]:                  # Print String in Green
                        print(f'{self.parent.GRN}',end = '')
                        print(f'{v[1]}', end="\t")
                        print(f'{self.parent.END}',end = '')
                print(f'')
        
        for k, v in stats.items():
            print(f'{k}', end="\t") # Print keys and TAB
            if 'hx8' == v[0]:
                print(f'{v[1]:02X}')
            elif 'arr8x' == v[0]:
                self.parent.dump_data(v[1],16)
            elif 'hx16' == v[0]:
                print(f'{v[1]:04X}')
            elif 'strw' == v[0]:
                print(f'{v[1]}')
            elif 'strg' == v[0]:
                print(f'{self.parent.GRN}',end = '')
                print(f'{v[1]}',end = '')
                print(f'{self.parent.END}')
    #----------------------------------
    def get_stats_and_files(self, img):
        entries, stats = self.get_dir(img)
        dirstring = 'TEST'

        return entries, dirstring
    #----------------------------------
    def convert_stats(self, ent, stat):
        string = ''
        string = 'Name      Password  StartTrk StartSec SecSize   Type  Start  End  PCnt  Hi-Line Spares\n'
        #print(ent)
        for e in ent:
            #string += ('{:8}|{:8}|{:8}|{:8}|{:8}|{:02X}|{:04X}|{:04X}|{:04X}|{:04X}|{:02X}|{:02X}|{:02X}\n'.format(e[0],e[1],e[2],e[3],e[4],e[5],e[6],e[7],e[8],e[9],e[10],e[11],e[12]))
            string += ('{:9};{:9};{:9};{:9};{:9};{:>7};0x{:04X};0x{:04X};0x{:04X};0x{:04X};0x{:02X};0x{:02X};0x{:02X}\n'.format(e[0],e[1],e[2],e[3],e[4],e[5],e[6],e[7],e[8],e[9],e[10],e[11],e[12]))

        string += ('Next Free Track: {:3} Next Free Sector: {:3} Free Sectors: 0x{:04X}'.format(stat[0],stat[1], int(stat[2]))) + '\n'
        return string
    #----------------------------------
    # adds the last entry which indicates no more files and free space on floppy
    def add_last_enty(self, img, pos, off):
        totalsec = (self.fspec["Imagesize"] - off) / self.fspec["bps"]
        nft,h,nfs = self.offset_to_chs(off)
        track = int(off / self.fspec["bps"]) # How many Tracks are these
        print(f'Next Free Trk.: {nft}, Next Free Sec.: {nfs}, Tracks used: {track} TotalFree: {totalsec}, 0x{int(totalsec):02X}')       
        ap = pos * self.fspec["Direntrysize"] + offset # actual Position
        clrpos = pos * self.fspec["Direntrysize"] + offset
        zeros = bytearray(0 for _ in range(self.fspec["Filestart"] - clrpos)) # Clear out 
        if self.verbose > 0:
            print(f'Clear: {len(zeros)}, 0x{len(zeros):04X}, Clrpos: 0x{clrpos:04X}')
        img[ap:ap+len(zeros)] = zeros
        img[ap] = 0xFF # Signature for no more entries
        img[ap+16] = nft # Next free Track
        img[ap+17] = nfs # Next free Sector
        free = int(totalsec)
        if self.verbose > 0:
            print(f'Total Free Trk.: {free}, 0x{free:04X}')
        img[ap+18:ap+20] = (free).to_bytes(2, 'big')
    #----------------------------------
    def get_file(self, imgfile, entry):
        data = bytearray()
        track = entry["StartTrack"][1]
        sector = entry["StartSector"][1]
        for s in range(entry["SizeinSecs"][1]):
            off = self.chs_to_offset(track, 0, sector)
            data += imgfile[off:(off+self.fspec["bps"])]
            #print(f'Track: {track}, Sector: {sector}, Offset: 0x{off:04X}')
            sector += 1
            if sector >= self.fspec["Sectors"]:
                sector = 0
                track += 1
        return data
    #----------------------------------
    # adds a file to the directory including all the necessary data
    def add_dir_enty(self, img, pos, name, passw, sttrk, stsec, siz, typ, saddr, eaddr, pc, hilin, sp0, sp1, sp2):
        ap = pos * self.fspec["Direntrysize"] + offset # actual Position
        text = bytearray(0x20 for _ in range(16)) # Clear out name and password
        namtxt = (name.encode("ascii")).strip()
        passtxt = (passw.encode("ascii")).strip()
        text[0:len(namtxt)] = namtxt
        text[8:8+len(passtxt)] = passtxt
        img[ap:ap+16] = text
        img[ap+16] = int(sttrk)
        img[ap+17] = int(stsec)
        img[ap+18:ap+20] = siz.to_bytes(2, 'big')
        img[ap+20] = typ
        img[ap+21:ap+23] = saddr.to_bytes(2, 'big')
        img[ap+23:ap+25] = eaddr.to_bytes(2, 'big')
        img[ap+25:ap+27] = pc.to_bytes(2, 'big')
        img[ap+27:ap+29] = hilin.to_bytes(2, 'big')
        img[ap+29] = sp0
        img[ap+30] = sp1
        img[ap+31] = sp2
    #----------------------------------
    def add_file(self, img, fdata, sttrk, stsec, siz):
        off = self.chs_to_offset(sttrk, 0, stsec)
        for idx in range(siz): # go through the sectors
            cstart = idx * self.fspec["bps"]
            start = off + cstart
            img[start:start+self.fspec["bps"]] = fdata[cstart:cstart+self.fspec["bps"]]
    #----------------------------------
    def add_files(self, statsfile, img, action):
        if action == 'CREATEBOOT':
            print(f'Creating Boot Image is no really necessary on FDOS.')
            print(f'Just put a file named $DOS in the FILES Directory and it will be the bootfile.')
 
        statslines = []
        statslines = (statsfile.split('\n'))[1:] # one line per track and start after header
        #----------------------------------
        # Here we add the filenames to the Directory
        # We need the stats file for Filetype, Startaddress, Endaddress, Program Counter,
        # Hiline (Basic) and three 'spares'.
        # Also the size can come from the stats file or from the actual filesize
        totalsz = 0
        c = 0
        h = 0
        s = 0
        for idx,line in enumerate(statslines):
            e = line.split(';')
            #print(f'Stats: {e} {idx}')
            if idx >= numfiles: # don't take the last line
                break
            name = e[0].strip()
            fn = name
            if ('/' in name):
                fn = name.replace('/', '_')
                #print(f'Looking for different name: {name}')
            fdata = self.parent.read_file((fdir+fn), 'binary') # Get the filedata
            #-------------------------------------------------------------------------
            # Get the filesize from the actual file and pad it to the next sector (alternative)
            #-------------------------------------------------------------------------
            #tempsiz = len(fdata)/self.fspec["bps"]  # Size (in sectors) from actual filesize
            #temprest = self.fspec["bps"] - (len(fdata)%self.fspec["bps"])  # Rest in sectors
            #zeros = bytearray(0 for _ in range(temprest))
            #fdata += zeros
            #nsiz = int(len(fdata)/self.fspec["bps"])
            #print(f'Tempsiz: {tempsiz}, Temprest: {temprest}, new: {nsiz}')
            #siz = nsiz # Use actual filesize padded to next sectorboundry
            #-------------------------------------------------------------------------
            siz = int(e[4], 0) # Use size from stats file
            c,h,s = self.offset_to_chs(totalsz)
            totalsz += siz * self.fspec["bps"]
            passw = e[1]
            if name == '$DOS':
                sttrk = int(e[2], 0)
                stsec = int(e[3], 0)
                totalsz += self.fspec["Sectors"] * self.fspec["bps"] # one track extra for directory
            else:
                sttrk = c
                stsec = s
                
            if 'Blank' in e[5]:
                typ = 0
            elif 'System' in e[5]:
                typ = 0x11
            elif 'Object' in e[5]:
                typ = 0x22
            elif 'Basic' in e[5]:
                typ = 0x55
            elif 'Cores' in e[5]:
                typ = 0x77
            elif 'B.Data' in e[5]:
                typ = 0x99
            saddr = int(e[6], 0)
            eaddr = int(e[7], 0)
            pc = int(e[8], 0)
            hilin = int(e[9], 0)
            sp0 = int(e[10], 0)
            sp1 = int(e[11], 0)
            sp2 = int(e[12], 0)
            print(f'Adding {name:8} to: {sttrk=:2} {stsec=:2} {siz=:2} NxtOff: {totalsz:>05X} Size of File: {len(fdata)/self.fspec["bps"]:>5.1f}')
            self.add_dir_enty(img, idx, name, passw, sttrk, stsec, siz, typ, saddr, eaddr, pc, hilin, sp0, sp1, sp2)
            #----------------------------------
            # Now add the actual files to the Image
            self.add_file(img, fdata, sttrk, stsec, siz)
        #c,h,s = self.offset_to_chs(totalsz)
        self.add_last_enty(img, idx, totalsz)
        return img
